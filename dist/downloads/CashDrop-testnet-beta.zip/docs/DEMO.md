# ZECATHON demo runbook

> Acceptance status: portable key generation, import, birthday rescan, and cross-wallet balance detection pass. Zallet beta.3's standalone-account PCZT sweep currently fails on the custom regtest schedule with a ZIP 212 enforcement error; do not present the portable sweep as complete until that upstream path is resolved and rerun.

1. Start two isolated Zallet wallets: **Alice** on port 50232 and **Bob** on a second local port.
2. Start Alice's CashDrop bridge and create a `0.05 ZEC` drop with a private note.
3. Fund the displayed Sapling-only Unified Address and mine/await one confirmation.
4. Save the recovery package, then copy the encrypted claim link.
5. Stop Alice's bridge to prove she is not involved in redemption.
6. Start Bob's bridge and open the link.
7. Enter Bob's shielded address and claim.
8. Show Zallet importing the key, proving, broadcasting, and returning the transaction ID.
9. Attempt the same link again and show the already-spent failure.
10. Explain that the public site never received the fragment or wallet data.

For the final submission, repeat steps 2–9 on public Zcash testnet and record the transaction ID.
