# CashDrop architecture

## Components

- **Hosted site:** public explanation and installer download only. It receives no keys, notes, wallet addresses, or claim telemetry.
- **Local web app:** served from `127.0.0.1:4173`; creates, opens, and displays CashDrops.
- **Local bridge:** loopback-only Node process that validates requests and speaks authenticated JSON-RPC to Zallet.
- **Local key service:** a minimal Rust process built on official `librustzcash` crates; creates standalone Sapling keys and listens only through a localhost-published container port.
- **Zallet + Zebra:** official wallet and consensus stack. Zebra verifies the chain; Zallet owns accounts, scans notes, builds proofs, and broadcasts transactions.

## Sender flow

1. The local key service generates a fresh standalone Sapling extended spending key and payment address from operating-system randomness.
2. CashDrop imports that key into Zallet and records its returned wallet account UUID.
3. The sender funds the Unified Address with the gift plus the claim-fee reserve.
4. After confirmation, the browser encrypts a versioned claim package with a random AES-256-GCM key.
5. Ciphertext and encryption key are encoded after `#` in a loopback claim URL.

## Recipient flow

1. The recipient opens the claim link with their own CashDrop installation.
2. The browser decrypts the package without making a network request containing the fragment.
3. The local bridge imports the Sapling spending key from the package and scans from its recorded birthday height.
4. Zallet sweeps the funded note to the recipient's shielded address under `FullPrivacy`.
5. The browser polls the local operation until a transaction ID or a terminal error is returned.

## Recovery and reclaim

The sender can export a recovery JSON containing the same portable key. Because sender and recipient possess equivalent spending authority, reclaim versus claim is deliberately first-valid-spend-wins. There is no custodial server and no administrator override.
