# CashDrop threat model

## Security goals

- Keep sender, recipient, amount, note, and spending authority off CashDrop infrastructure.
- Preserve shielded settlement from the temporary note to the recipient's shielded address.
- Make a claim independently redeemable without the sender being online.
- Fail closed on malformed, tampered, wrong-network, or already-spent claims.

## Trusted components

- The sender's and recipient's operating systems.
- Their local CashDrop bridge and official Zallet/Zebra binaries.
- The private channel used to transmit the bearer link.

## Untrusted components

- The hosted CashDrop site, web servers, analytics systems, URL previewers, and public messaging metadata.
- The network path between Zebra and peers.
- Anyone who obtains the complete claim URL.

## Principal threats and mitigations

| Threat | Mitigation | Residual risk |
| --- | --- | --- |
| Hosted server learns claim secret | Claim data is stored only in the URL fragment and claims target loopback | Browser extensions, screenshots, clipboard history, and the recipient device can still read it |
| Link tampering | AES-256-GCM authentication and strict package validation | A stolen intact link remains spendable |
| Link preview unfurls secret | Fragments are excluded from HTTP requests | Some messaging clients may expose full text to their own local scanners |
| Remote access to wallet RPC | CashDrop binds to loopback and Zallet uses cookie/basic authentication | Malware running as the same user remains in scope |
| Wrong-chain claim | Package network must equal the local bridge network | Misconfigured third-party wallets may behave differently |
| Double claim/reclaim race | Zcash nullifiers enforce one valid spend | User experience must explain that the first mined spend wins |
| Amount correlation | Funding and sweep remain shielded | Timing and exact-amount patterns may still permit statistical inference |
| Recovery loss | Sender can download a recovery package and back up the Zallet volume | Losing both makes the funds unrecoverable |

## Explicit non-goals

- Protecting a bearer link after the recipient device is compromised.
- Hiding that a user accessed the public CashDrop marketing site.
- Reversing a completed claim.
- Mainnet safety before an independent audit.
