const alphabet = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';
const polymod = values => {
  const generators = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3];
  let checksum = 1;
  for (const value of values) {
    const top = checksum >>> 25;
    checksum = ((checksum & 0x1ffffff) << 5) ^ value;
    for (let i = 0; i < 5; i += 1) if ((top >>> i) & 1) checksum ^= generators[i];
  }
  return checksum >>> 0;
};
const expand = prefix => [...prefix].map(char => char.charCodeAt(0) >>> 5).concat([0], [...prefix].map(char => char.charCodeAt(0) & 31));
const withHrp = (encoded, prefix) => {
  if (encoded.startsWith(`${prefix}1`)) return encoded;
  const separator = encoded.lastIndexOf('1');
  if (separator < 1) throw new Error('Invalid Bech32 key material.');
  const words = [...encoded.slice(separator + 1, -6)].map(char => alphabet.indexOf(char));
  if (words.some(value => value < 0)) throw new Error('Invalid Bech32 key material.');
  const mod = polymod([...expand(prefix), ...words, 0, 0, 0, 0, 0, 0]) ^ 1;
  const checksum = Array.from({ length: 6 }, (_, i) => (mod >>> (5 * (5 - i))) & 31);
  return `${prefix}1${[...words, ...checksum].map(value => alphabet[value]).join('')}`;
};

export function createKeyGenerator({ url, network = 'regtest', fetchImpl = fetch }) {
  return async function generateKey() {
    const response = await fetchImpl(`${url}/key`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: '{}',
      signal: AbortSignal.timeout(20_000)
    });
    if (!response.ok) throw new Error(`Key generator HTTP ${response.status}`);
    const result = await response.json();
    if (typeof result.spendingKey !== 'string' || typeof result.sourceAddress !== 'string') throw new Error('Key generator returned an invalid keypair.');
    if (network === 'regtest') return {
      spendingKey: withHrp(result.spendingKey, 'secret-extended-key-regtest'),
      sourceAddress: withHrp(result.sourceAddress, 'zregtestsapling')
    };
    return result;
  };
}

