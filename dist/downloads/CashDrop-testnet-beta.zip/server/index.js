import http from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { config } from './config.js';
import { createRpcClient } from './rpc.js';
import { createStore } from './store.js';
import { createWallet } from './wallet.js';
import { createKeyGenerator } from './keygen.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const publicDir = path.join(root, 'public');
const store = createStore(config.dataDir);
const rpc = createRpcClient({ url: config.rpcUrl, user: config.rpcUser, password: config.rpcPassword });
const generateKey = createKeyGenerator({ url: config.keygenUrl, network: config.network });
const wallet = createWallet(rpc, { network: config.network, generateKey });
const SECRET_FIELDS = new Set(['account', 'spendingKey']);
const publicDrop = drop => Object.fromEntries(Object.entries(drop).filter(([key]) => !SECRET_FIELDS.has(key)));
const claimBundle = drop => ({ version: 2, id: drop.id, amount: drop.amount, note: drop.note, network: drop.network, sourceAddress: drop.sourceAddress, spendingKey: drop.spendingKey, birthdayHeight: drop.birthdayHeight });
const isShielded = address => typeof address === 'string' && (address.startsWith('u') || address.startsWith('z'));
const json = (res, status, body) => { res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' }); res.end(JSON.stringify(body)); };
const parseBody = async req => { const chunks = []; for await (const chunk of req) chunks.push(chunk); const data = Buffer.concat(chunks); if (data.length > 64_000) throw new Error('Request too large'); return JSON.parse(data.toString('utf8') || '{}'); };

async function refreshDrop(drop) {
  if (drop.status === 'awaiting_funds') {
    const balance = await wallet.balance(drop.account);
    if (balance >= drop.fundingAmount) return store.put({ ...drop, status: 'ready', balance, updatedAt: new Date().toISOString() });
  }
  if (drop.status === 'reclaiming' && drop.operationId) {
    const [operation] = await wallet.operation(drop.operationId);
    if (operation?.status === 'success') return store.put({ ...drop, status: 'reclaimed', txid: operation.result?.txid || operation.result?.txids?.[0], completedAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    if (operation?.status === 'failed') return store.put({ ...drop, status: 'ready', operationError: operation.error?.message || 'Transaction failed', updatedAt: new Date().toISOString() });
  }
  return drop;
}

async function api(req, res, url) {
  if (req.method === 'GET' && url.pathname === '/api/status') {
    try { return json(res, 200, await wallet.status()); } catch (error) { return json(res, 503, { connected: false, network: config.network, error: error.message }); }
  }
  if (req.method === 'GET' && url.pathname === '/api/drops') return json(res, 200, (await store.list()).map(publicDrop));
  if (req.method === 'POST' && url.pathname === '/api/drops') {
    const body = await parseBody(req); const drop = await wallet.createDrop({ amount: Number(body.amount), note: String(body.note || '') }); await store.put(drop); return json(res, 201, publicDrop(drop));
  }
  if (req.method === 'POST' && url.pathname === '/api/claims') {
    const body = await parseBody(req);
    if (body.network !== config.network) return json(res, 409, { error: `This drop is for ${body.network}; this wallet is on ${config.network}.` });
    if (!isShielded(body.sourceAddress) || !isShielded(body.recipientAddress)) return json(res, 400, { error: 'A valid shielded source and recipient address are required.' });
    const amount = Number(body.amount); if (!Number.isFinite(amount) || amount <= 0) return json(res, 400, { error: 'Invalid claim amount.' });
    const imported = await wallet.importDropKey(String(body.spendingKey || ''), Number(body.birthdayHeight || 0), body.sourceAddress);
    await wallet.waitUntilSynced();
    const sent = await wallet.sendFromAccount(imported.account, body.recipientAddress, amount);
    return json(res, 200, { id: String(body.id || ''), status: 'success', txid: sent.txid || sent.txids?.[0] || sent });
  }
  const opMatch = url.pathname.match(/^\/api\/operations\/([^/]+)$/);
  if (req.method === 'GET' && opMatch) {
    const [operation] = await wallet.operation(decodeURIComponent(opMatch[1]));
    if (!operation) return json(res, 404, { error: 'Operation not found' });
    return json(res, 200, { status: operation.status, txid: operation.result?.txid || operation.result?.txids?.[0], error: operation.error?.message });
  }
  const match = url.pathname.match(/^\/api\/drops\/([^/]+)(?:\/(status|package|recovery|reclaim))?$/);
  if (!match) return json(res, 404, { error: 'Not found' });
  let drop = await store.get(decodeURIComponent(match[1])); if (!drop) return json(res, 404, { error: 'Drop not found' });
  if (req.method === 'GET' && (!match[2] || match[2] === 'status')) { drop = await refreshDrop(drop); return json(res, 200, publicDrop(drop)); }
  if (req.method === 'GET' && match[2] === 'package') { drop = await refreshDrop(drop); if (!drop.spendingKey) return json(res, 409, { error: 'This legacy drop predates portable claims. Create a new drop.' }); if (drop.status !== 'ready') return json(res, 409, { error: `Drop is ${drop.status}` }); return json(res, 200, claimBundle(drop)); }
  if (req.method === 'GET' && match[2] === 'recovery') return json(res, 200, { ...claimBundle(drop), recovery: true, createdAt: drop.createdAt });
  if (req.method === 'POST' && match[2] === 'reclaim') {
    drop = await refreshDrop(drop); if (drop.status !== 'ready') return json(res, 409, { error: `Drop is ${drop.status}` });
    const body = await parseBody(req); if (!isShielded(body.address)) return json(res, 400, { error: 'Enter a shielded Zcash address.' });
    const operationId = await wallet.send(drop.sourceAddress, body.address, drop.amount);
    drop = await store.put({ ...drop, status: 'reclaiming', operationId, updatedAt: new Date().toISOString() }); return json(res, 202, publicDrop(drop));
  }
  return json(res, 405, { error: 'Method not allowed' });
}

const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml' };
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`); if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    const requested = url.pathname === '/' ? 'index.html' : url.pathname.slice(1); const file = path.resolve(publicDir, requested); if (!file.startsWith(publicDir)) return json(res, 403, { error: 'Forbidden' });
    try { const body = await readFile(file); res.writeHead(200, { 'content-type': types[path.extname(file)] || 'application/octet-stream', 'x-content-type-options': 'nosniff' }); res.end(body); }
    catch (error) { if (error.code !== 'ENOENT') throw error; const body = await readFile(path.join(publicDir, 'index.html')); res.writeHead(200, { 'content-type': types['.html'] }); res.end(body); }
  } catch (error) { json(res, error instanceof SyntaxError ? 400 : 500, { error: error.message }); }
});
server.listen(config.port, config.host, () => { console.log(`CashDrop running at http://${config.host}:${config.port}`); console.log(`Network: ${config.network}; wallet RPC: ${config.rpcUrl}`); });
