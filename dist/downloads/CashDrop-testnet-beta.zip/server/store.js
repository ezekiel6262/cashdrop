import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import path from 'node:path';

const EMPTY = { version: 1, drops: {} };

export function createStore(dataDir) {
  const file = path.join(dataDir, 'drops.json');
  async function read() {
    try { return JSON.parse(await readFile(file, 'utf8')); }
    catch (error) {
      if (error.code === 'ENOENT') return structuredClone(EMPTY);
      throw error;
    }
  }
  async function write(data) {
    await mkdir(dataDir, { recursive: true });
    const temp = `${file}.${process.pid}.tmp`;
    await writeFile(temp, JSON.stringify(data, null, 2), { mode: 0o600 });
    await rename(temp, file);
  }
  return {
    async list() { return Object.values((await read()).drops); },
    async get(id) { return (await read()).drops[id] || null; },
    async put(drop) {
      const data = await read();
      data.drops[drop.id] = drop;
      await write(data);
      return drop;
    }
  };
}
