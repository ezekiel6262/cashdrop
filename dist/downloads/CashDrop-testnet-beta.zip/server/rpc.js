export class RpcError extends Error {
  constructor(message, code, data) {
    super(message);
    this.name = 'RpcError';
    this.code = code;
    this.data = data;
  }
}

export function createRpcClient({ url, user, password, fetchImpl = fetch }) {
  let id = 0;
  return async function rpc(method, params = []) {
    const auth = Buffer.from(`${user}:${password}`).toString('base64');
    const response = await fetchImpl(url, {
      method: 'POST',
      headers: {
        authorization: `Basic ${auth}`,
        'content-type': 'application/json'
      },
      body: JSON.stringify({ jsonrpc: '2.0', id: ++id, method, params }),
      signal: AbortSignal.timeout(20_000)
    });
    if (!response.ok) throw new RpcError(`RPC HTTP ${response.status}`, response.status);
    const body = await response.json();
    if (body.error) throw new RpcError(body.error.message, body.error.code, body.error.data);
    return body.result;
  };
}
