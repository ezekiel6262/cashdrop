import crypto from 'node:crypto';

export const FEE_ZEC = 0.0001;
const round8 = value => Number(Number(value).toFixed(8));

export function createWallet(rpc, { network = 'regtest', generateKey } = {}) {
  async function status() {
    const info = await rpc('getwalletstatus');
    return { connected: true, network, blocks: info.node_tip?.height ?? 0, walletBlocks: info.wallet_tip?.height ?? 0, fullySyncedHeight: info.fully_synced_height ?? 0, chain: network };
  }

  async function newPortableAddress() {
    const tip = await status();
    if (!generateKey) throw new Error('CashDrop key generator is not configured.');
    const { sourceAddress, spendingKey } = await generateKey();
    const before = await rpc('z_listaccounts');
    const known = new Set((before || []).map(item => item.account_uuid));
    const imported = await rpc('z_importkey', [spendingKey, 'no', Math.max(0, tip.blocks - 10)]);
    const after = await rpc('z_listaccounts');
    const account = imported?.account_uuid ?? (after || []).find(item => !known.has(item.account_uuid))?.account_uuid;
    if (!account) throw new Error('Zallet imported the drop key but did not return its account.');
    return { account, address: sourceAddress, sourceAddress, spendingKey, birthdayHeight: Math.max(0, tip.blocks - 10) };
  }

  async function waitUntilSynced(timeoutMs = 180_000) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      try {
        const current = await status();
        if (current.walletBlocks >= current.blocks && current.blocks > 0) return current;
      } catch (error) {
        if (Date.now() >= deadline) throw error;
      }
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
    throw new Error('Wallet rescan did not finish in time. Try the claim again after the wallet catches up.');
  }

  return {
    status,
    async createDrop({ amount, note = '' }) {
      if (!Number.isFinite(amount) || amount <= 0 || amount > 1000) throw new Error('Amount must be between 0 and 1,000 ZEC.');
      if (note.length > 120) throw new Error('Note must be 120 characters or fewer.');
      const target = await newPortableAddress();
      const now = new Date().toISOString();
      return { id: `CD-${crypto.randomBytes(3).toString('hex').toUpperCase()}`, amount: round8(amount), fundingAmount: round8(amount + FEE_ZEC), feeReserve: FEE_ZEC, note, network, ...target, status: 'awaiting_funds', createdAt: now, updatedAt: now };
    },
    async importDropKey(spendingKey, birthdayHeight = 0, expectedAddress = '') {
      if (typeof spendingKey !== 'string' || spendingKey.length < 32) throw new Error('Invalid CashDrop spending key.');
      await rpc('z_importkey', [spendingKey, 'yes', Math.max(0, Number(birthdayHeight) || 0)]);
      if (!expectedAddress) return { spendFrom: expectedAddress };
      const accounts = await rpc('z_listaccounts');
      for (const account of accounts || []) {
        for (const item of account.addresses || []) {
          const receivers = await rpc('z_listunifiedreceivers', [item.ua]);
          if (receivers.sapling === expectedAddress) return { account: account.account_uuid, spendFrom: item.ua };
        }
      }
      throw new Error('Imported key was not mapped to a wallet payment source.');
    },
    waitUntilSynced,
    async balance(account) {
      const result = await rpc('z_getbalanceforaccount', [account, 1]);
      const pools = result?.pools || result;
      const valueZat = Object.values(pools || {}).reduce((sum, pool) => sum + Number(pool?.valueZat ?? pool?.value_zat ?? 0), 0);
      return valueZat / 1e8;
    },
    async send(sourceAddress, address, amount) {
      return rpc('z_sendmany', [sourceAddress, [{ address, amount: round8(amount) }], 1, null, 'FullPrivacy']);
    },
    async sendFromAccount(account, address, amount) {
      return rpc('z_sendfromaccount', [account, 'sapling', [{ address, amount: round8(amount) }], 1, 'FullPrivacy']);
    },
    async operation(id) { return rpc('z_getoperationstatus', [[id]]); }
  };
}
