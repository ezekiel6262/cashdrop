import path from 'node:path';

const network = process.env.CASHDROP_NETWORK || 'regtest';

export const config = Object.freeze({
  host: process.env.CASHDROP_HOST || '127.0.0.1',
  port: Number(process.env.CASHDROP_PORT || 4173),
  rpcUrl: process.env.ZCASH_RPC_URL || 'http://127.0.0.1:50232',
  rpcUser: process.env.ZCASH_RPC_USER || 'zebra',
  rpcPassword: process.env.ZCASH_RPC_PASSWORD || 'zebra',
  keygenUrl: process.env.CASHDROP_KEYGEN_URL || 'http://127.0.0.1:4174',
  dataDir: path.resolve(process.env.CASHDROP_DATA_DIR || path.join('.cashdrop', network)),
  network
});
