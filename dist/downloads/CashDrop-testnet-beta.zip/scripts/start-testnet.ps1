param(
  [string]$Z3Path = (Join-Path $PSScriptRoot '..\..\z3')
)

$ErrorActionPreference = 'Stop'
$Z3Path = (Resolve-Path -LiteralPath $Z3Path).Path

Push-Location $Z3Path
try {
  docker compose -f docker-compose.yml --env-file .env.testnet up -d zebra cookie-permissions
  docker compose -f docker-compose.yml --env-file .env.testnet up -d --no-deps zallet
  if ($LASTEXITCODE -ne 0) { throw 'Could not start the Zcash testnet stack.' }
} finally {
  Pop-Location
}

$cookie = docker run --rm -v z3-testnet-zallet:/data busybox cat /data/.cookie
if ($LASTEXITCODE -ne 0 -or -not $cookie) { throw 'Could not read the local Zallet RPC cookie.' }
$parts = $cookie.Split(':', 2)
$env:ZCASH_RPC_URL = 'http://127.0.0.1:40232'
$env:ZCASH_RPC_USER = $parts[0]
$env:ZCASH_RPC_PASSWORD = $parts[1]
$env:CASHDROP_NETWORK = 'testnet'

Push-Location (Join-Path $PSScriptRoot '..')
try { npm start } finally { Pop-Location }
