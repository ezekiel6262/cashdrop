import test from 'node:test';
import assert from 'node:assert/strict';
import { createRpcClient, RpcError } from '../server/rpc.js';

test('RPC client authenticates and returns result', async () => {
  const fetchImpl = async (_url, options) => {
    assert.match(options.headers.authorization, /^Basic /);
    assert.equal(JSON.parse(options.body).method, 'getblockchaininfo');
    return new Response(JSON.stringify({ jsonrpc:'2.0', id:1, result:{ blocks:42 } }), { status:200 });
  };
  const rpc = createRpcClient({ url:'http://local', user:'u', password:'p', fetchImpl });
  assert.deepEqual(await rpc('getblockchaininfo'), { blocks:42 });
});

test('RPC client surfaces JSON-RPC errors', async () => {
  const fetchImpl = async () => new Response(JSON.stringify({ error:{ code:-32601, message:'Method not found' } }), { status:200 });
  const rpc = createRpcClient({ url:'http://local', user:'u', password:'p', fetchImpl });
  await assert.rejects(() => rpc('missing'), error => error instanceof RpcError && error.code === -32601);
});
