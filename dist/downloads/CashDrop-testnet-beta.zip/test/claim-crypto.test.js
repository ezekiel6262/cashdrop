import test from 'node:test';
import assert from 'node:assert/strict';
import { openClaim, sealClaim } from '../public/crypto.js';

test('claim package survives an authenticated encryption round trip', async () => {
  const input = { version:2, id:'CD-123ABC', amount:.05, note:'private', network:'regtest', sourceAddress:'zregtestsapling1source', spendingKey:'secret-extended-key-test1portable', birthdayHeight:490 };
  const token = await sealClaim(input);
  assert.match(token, /^v1\./);
  assert.deepEqual(await openClaim(token), input);
});

test('tampered claim packages fail closed', async () => {
  const token = await sealClaim({ id:'CD-123ABC' });
  const tampered = `${token.slice(0,-2)}AA`;
  await assert.rejects(() => openClaim(tampered), /could not be opened/);
});
