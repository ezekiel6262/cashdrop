import test from 'node:test';
import assert from 'node:assert/strict';
import { createWallet } from '../server/wallet.js';

test('creates a fresh Sapling funding address and reserves claim fee', async () => {
  const calls=[];
  let listed=0;
  const rpc=async(method)=>{calls.push(method);if(method==='getwalletstatus')return{node_tip:{height:500},wallet_tip:{height:500},fully_synced_height:500};if(method==='z_listaccounts')return ++listed===1?[]:[{account_uuid:'account-3'}];if(method==='z_importkey')return null;};
  const generateKey=async()=>({sourceAddress:'zregtestsapling1fresh',spendingKey:'secret-extended-key-test1portable'});
  const wallet=createWallet(rpc,{network:'regtest',generateKey});
  const drop=await wallet.createDrop({amount:.05,note:'hello'});
  assert.equal(drop.address,'zregtestsapling1fresh');
  assert.equal(drop.sourceAddress,'zregtestsapling1fresh');
  assert.equal(drop.spendingKey,'secret-extended-key-test1portable');
  assert.equal(drop.birthdayHeight,490);
  assert.equal(drop.fundingAmount,.0501);
  assert.equal(drop.status,'awaiting_funds');
  assert.deepEqual(calls,['getwalletstatus','z_listaccounts','z_importkey','z_listaccounts']);
});

test('imports a portable key from its birthday before sweeping', async () => {
  const seen=[];
  const wallet=createWallet(async(method,params)=>{seen.push([method,params]);return true;});
  await wallet.importDropKey('secret-extended-key-test1portable',490);
  assert.deepEqual(seen,[['z_importkey',['secret-extended-key-test1portable','yes',490]]]);
});

test('rejects invalid amounts before touching the wallet', async () => {
  const wallet=createWallet(async()=>assert.fail('RPC called'));
  await assert.rejects(()=>wallet.createDrop({amount:0}),/between 0 and 1,000/);
});
