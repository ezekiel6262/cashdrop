const enc = new TextEncoder();
const dec = new TextDecoder();
const b64url = bytes => btoa(String.fromCharCode(...bytes)).replaceAll('+','-').replaceAll('/','_').replaceAll('=','');
const fromB64url = value => Uint8Array.from(atob(value.replaceAll('-','+').replaceAll('_','/') + '==='.slice((value.length + 3) % 4)), c => c.charCodeAt(0));

export async function sealClaim(payload) {
  const key = crypto.getRandomValues(new Uint8Array(32));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const cryptoKey = await crypto.subtle.importKey('raw', key, 'AES-GCM', false, ['encrypt']);
  const ciphertext = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, cryptoKey, enc.encode(JSON.stringify(payload))));
  return `v1.${b64url(iv)}.${b64url(ciphertext)}.${b64url(key)}`;
}

export async function openClaim(token) {
  const [version, iv, ciphertext, key] = token.split('.');
  if (version !== 'v1' || !iv || !ciphertext || !key) throw new Error('This CashDrop link is incomplete or invalid.');
  const cryptoKey = await crypto.subtle.importKey('raw', fromB64url(key), 'AES-GCM', false, ['decrypt']);
  try {
    const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: fromB64url(iv) }, cryptoKey, fromB64url(ciphertext));
    return JSON.parse(dec.decode(plain));
  } catch { throw new Error('This CashDrop link could not be opened.'); }
}
