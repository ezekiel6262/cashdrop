import { openClaim, sealClaim } from './crypto.js';

const app = document.querySelector('#app');
const pill = document.querySelector('#network-pill');
const toastEl = document.querySelector('#toast');
const fee = 0.0001;
let node = { connected: false, network: 'regtest' };

const money = n => Number(n || 0).toFixed(4);
const escape = s => String(s ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const toast = text => { toastEl.textContent = text; toastEl.classList.add('show'); setTimeout(()=>toastEl.classList.remove('show'),2200); };
async function request(url, options) {
  const response = await fetch(url, options);
  const body = await response.json();
  if (!response.ok) throw new Error(body.error || 'Request failed');
  return body;
}
async function refreshNode() {
  try { node = await request('/api/status'); }
  catch { node = { connected:false, network:'offline' }; }
  pill.textContent = node.connected ? `${node.network} · ${node.blocks} blocks`.toUpperCase() : 'WALLET OFFLINE';
  pill.className = `pill ${node.connected ? 'online' : 'offline'}`;
}
const envelope = (amount='0.0500', note='A private thank-you', id='CD-····', stamp='SEALED') => `<div class="envelope"><div class="env-top"><span>CASHDROP / SHIELDED ZEC</span><span>ONE-TIME</span></div><div class="env-amount">${escape(amount)} ZEC</div><div class="env-note">${escape(note || 'No note')}</div><div class="env-bottom"><span>${escape(id)}</span><span class="stamp">${escape(stamp)}</span></div></div>`;

function home() {
  app.innerHTML = `<section class="hero"><div><div class="eyebrow">PRIVATE DIGITAL CASH</div><h1>Cash you can hand over in a message.</h1><p>Seal ZEC in a one-time envelope, send the link privately, and the recipient sweeps it into their own shielded wallet.</p><div class="hero-actions"><a class="btn primary" href="#/create">Create a CashDrop →</a><a class="btn" href="#/claim">I received one</a></div><div class="feature-row"><div class="feature"><b>Seal it</b><p>A fresh shielded destination for every drop.</p></div><div class="feature"><b>Send it</b><p>The encrypted claim travels in the URL fragment.</p></div><div class="feature"><b>They claim it</b><p>No account, email, or identity required.</p></div></div></div>${envelope()}</section>`;
}

function create() {
  app.innerHTML = `<div class="eyebrow">CREATE / 01</div><div class="split"><section><h2>Seal an envelope</h2><p>Choose what they receive. A small reserve pays the claim transaction fee.</p><form id="create-form"><label class="field"><span>They receive</span><div class="amount"><input id="amount" inputmode="decimal" value="0.05" aria-label="ZEC amount"><b>ZEC</b></div></label><div class="presets">${[.01,.05,.1,.5].map(v=>`<button type="button" data-amount="${v}">${v} ZEC</button>`).join('')}</div><label class="field"><span>Private note <small>(optional)</small></span><textarea id="note" maxlength="120" rows="4" placeholder="Thanks for helping with the event"></textarea></label><div class="notice" style="margin-top:20px">The claim link is bearer money. Anyone who gets it can claim the funds. Send it through a private, encrypted channel.</div><button class="btn primary" style="margin-top:20px" ${node.connected?'':'disabled'}>${node.connected?'Create funding address':'Start the local wallet first'}</button><div id="form-error" class="error"></div></form></section><aside><div id="preview">${envelope('0.0500','Your private note')}</div><div class="card summary"><div class="row"><span>They receive</span><strong id="receive">0.0500 ZEC</strong></div><div class="row"><span>Claim fee reserve</span><strong>0.0001 ZEC</strong></div><div class="row total"><span>You fund</span><strong id="fund">0.0501 ZEC</strong></div></div></aside></div>`;
  const amount = document.querySelector('#amount'), note = document.querySelector('#note');
  const update = () => { const value=Math.max(0,Number(amount.value)||0); document.querySelector('#receive').textContent=`${money(value)} ZEC`; document.querySelector('#fund').textContent=`${money(value+fee)} ZEC`; document.querySelector('#preview').innerHTML=envelope(money(value),note.value||'Your private note'); };
  amount.addEventListener('input', update); note.addEventListener('input', update);
  document.querySelectorAll('[data-amount]').forEach(b=>b.onclick=()=>{amount.value=b.dataset.amount;update()});
  document.querySelector('#create-form').onsubmit = async event => {
    event.preventDefault(); const button=event.submitter; button.disabled=true; button.textContent='Creating private address…';
    try { const drop=await request('/api/drops',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({amount:Number(amount.value),note:note.value})}); location.hash=`#/fund/${drop.id}`; }
    catch(error){document.querySelector('#form-error').textContent=error.message;button.disabled=false;button.textContent='Create funding address'}
  };
}

async function fund(id) {
  try {
    const drop=await request(`/api/drops/${encodeURIComponent(id)}/status`);
    if(['claimed','reclaimed'].includes(drop.status)) {
      app.innerHTML=`<div class="empty"><div class="eyebrow">${drop.status.toUpperCase()}</div><h2>${drop.status==='claimed'?'This envelope was claimed.':'Funds returned to the sender.'}</h2><p>${drop.txid?`Transaction ${escape(drop.txid)}`:'The shielded transaction completed.'}</p><a class="btn" href="#/drops">Back to my drops</a></div>`;
      return;
    }
    app.innerHTML=`<div class="eyebrow">CREATE / 02</div><div class="split"><section><h2>${drop.status==='ready'?'Envelope funded':'Fill the envelope'}</h2><p>Send exactly <strong>${money(drop.fundingAmount)} ZEC</strong> from a shielded wallet to this one-time address.</p><div class="address">${escape(drop.address)}</div><div class="actions"><button id="copy-address" class="btn primary">Copy address</button><button id="download" class="btn">Save recovery file</button></div><div class="card" style="margin-top:24px"><div class="statusline"><span class="dot"></span>${drop.status==='ready'?'Funds detected and ready to share':'Waiting for shielded funds…'}</div></div>${drop.status==='ready'?'<button id="share" class="btn primary" style="margin-top:20px">Reveal sharing link →</button>':'<p class="secret-hint">This page checks for a confirmed shielded note every few seconds.</p>'}</section><aside>${envelope(money(drop.amount),drop.note,drop.id,drop.status==='ready'?'READY':'WAITING')}</aside></div>`;
    document.querySelector('#copy-address').onclick=async()=>{await navigator.clipboard.writeText(drop.address);toast('Funding address copied')};
    document.querySelector('#download').onclick=async()=>{try{const recovery=await request(`/api/drops/${encodeURIComponent(drop.id)}/recovery`);download(`${drop.id}-recovery.json`,recovery)}catch(error){toast(error.message)}};
    if(drop.status==='ready') {
      document.querySelector('#share').insertAdjacentHTML('afterend','<button id="reclaim" class="btn" style="margin-top:20px;margin-left:10px">Reclaim instead</button>');
      document.querySelector('#share').onclick=()=>share(drop);
      document.querySelector('#reclaim').onclick=async()=>{const address=prompt('Shielded address to return the funds to:');if(!address)return;try{await request(`/api/drops/${encodeURIComponent(drop.id)}/reclaim`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({address:address.trim()})});toast('Reclaim transaction submitted');setTimeout(()=>fund(id),1000)}catch(error){toast(error.message)}};
    } else setTimeout(()=>{if(location.hash===`#/fund/${id}`)fund(id)},6000);
  } catch(error){app.innerHTML=`<div class="empty"><h2>Could not load this drop</h2><p>${escape(error.message)}</p><a class="btn" href="#/drops">Back to my drops</a></div>`}
}

async function share(drop) {
  const bundle=await request(`/api/drops/${encodeURIComponent(drop.id)}/package`);
  const token=await sealClaim(bundle);
  const link=`http://127.0.0.1:4173/#/claim/${token}`;
  app.innerHTML=`<div class="split"><section>${envelope(money(drop.amount),drop.note,drop.id,'READY')}</section><section><div class="eyebrow">CREATE / 03</div><h2>Now hand it over.</h2><p>Send this through a private channel. The recipient opens it with their own local CashDrop app—even if your computer is offline.</p><div class="address">${escape(link)}</div><div class="actions"><button id="copy-link" class="btn primary">Copy private link</button><button id="native-share" class="btn">Share…</button><a class="btn" href="#/drops">Done</a></div><div class="notice" style="margin-top:24px">The encrypted URL fragment contains the one-time Sapling spending key. It is bearer money: whoever gets it first can sweep the note.</div></section></div>`;
  document.querySelector('#copy-link').onclick=async()=>{await navigator.clipboard.writeText(link);toast('Private claim link copied')};
  const native=document.querySelector('#native-share'); native.onclick=async()=>navigator.share?navigator.share({title:'A private CashDrop',text:`You received ${money(drop.amount)} ZEC`,url:link}):navigator.clipboard.writeText(link);
}

async function drops() {
  let list=[]; try{list=await request('/api/drops')}catch{}
  app.innerHTML=`<div style="display:flex;justify-content:space-between;align-items:end;gap:20px;margin-bottom:30px"><div><div class="eyebrow">LOCAL WALLET</div><h2>My drops</h2><p>Stored only by the CashDrop bridge on this device.</p></div><a class="btn primary" href="#/create">+ New drop</a></div>${list.length?`<div class="drop-grid">${list.map(d=>`<button class="drop" data-id="${escape(d.id)}"><div class="drop-head"><span class="drop-amount">${money(d.amount)} ZEC</span><span class="badge">${escape(d.status.replaceAll('_',' '))}</span></div><p>${escape(d.note||'No note')} · ${escape(d.id)}</p></button>`).join('')}</div>`:`<div class="empty"><h2>No drops yet</h2><p>Your private envelopes will appear here.</p><a class="btn primary" href="#/create">Create the first one</a></div>`}`;
  document.querySelectorAll('[data-id]').forEach(el=>el.onclick=()=>location.hash=`#/fund/${el.dataset.id}`);
}

function download(name,data){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));a.download=name;a.click();URL.revokeObjectURL(a.href)}

async function watchOperation(operationId, gift) {
  for (let attempt=0; attempt<120; attempt++) {
    const operation=await request(`/api/operations/${encodeURIComponent(operationId)}`);
    if(operation.status==='success') {
      app.innerHTML=`<div class="empty"><div class="eyebrow">CLAIMED</div><h2>${money(gift.amount)} ZEC is yours.</h2><p>The shielded sweep was broadcast successfully.</p>${operation.txid?`<div class="address">${escape(operation.txid)}</div>`:''}<a class="btn" href="#/">Done</a></div>`;
      return;
    }
    if(operation.status==='failed') throw new Error(operation.error||'The claim transaction failed.');
    await new Promise(resolve=>setTimeout(resolve,3000));
  }
  throw new Error('The wallet is still proving. Check My drops or try again shortly.');
}

async function claim(token='') {
  let gift=null,error=''; if(token){try{gift=await openClaim(token)}catch(e){error=e.message}}
  app.innerHTML=`<section class="claimbox"><div class="eyebrow">CLAIM A CASHDROP</div>${gift?`${envelope(money(gift.amount),gift.note,gift.id,'FOR YOU')}<div class="card" style="margin-top:28px"><h2>Sweep ${money(gift.amount)} ZEC</h2><p>Enter your own shielded Zcash address. The drop will be spent directly to it.</p><form id="claim-form"><label class="field"><span>Your shielded address</span><input id="claim-address" autocomplete="off" placeholder="u1… or zs1…" required></label><button class="btn primary" style="margin-top:18px">Claim privately →</button><div class="error" id="claim-error"></div></form></div>`:`<h1>Open private cash.</h1><p>Paste the complete CashDrop link you received. It is processed locally.</p><form id="open-form"><label class="field"><span>CashDrop link</span><textarea id="claim-link" rows="5" placeholder="https://…#/claim/v1.…"></textarea></label><button class="btn primary" style="margin-top:18px">Open envelope</button><div class="error">${escape(error)}</div></form>`}</section>`;
  if(!gift){document.querySelector('#open-form').onsubmit=e=>{e.preventDefault();const value=document.querySelector('#claim-link').value.trim();const part=value.includes('#/claim/')?value.split('#/claim/')[1]:value;location.hash=`#/claim/${part}`};return}
  document.querySelector('#claim-form').onsubmit=async e=>{e.preventDefault();const button=e.submitter;button.disabled=true;button.textContent='Importing one-time key…';try{const claim=await request('/api/claims',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({...gift,recipientAddress:document.querySelector('#claim-address').value.trim()})});if(claim.txid){renderClaimSuccess(gift,claim.txid);return}app.innerHTML=`<div class="empty"><div class="eyebrow">CLAIM SUBMITTED</div><h2>Creating the shielded sweep…</h2><p>Your local wallet imported the one-time key and is proving the transaction.</p></div>`;await watchOperation(claim.operationId,gift)}catch(err){app.innerHTML=`<section class="claimbox"><div class="error">${escape(err.message)}</div><a class="btn" href="${location.hash}">Try again</a></section>`}};
}

async function route(){await refreshNode();const path=location.hash.slice(2).split('/');switch(path[0]){case'create':create();break;case'drops':await drops();break;case'fund':await fund(path[1]);break;case'claim':await claim(path.slice(1).join('/'));break;default:home()}app.focus()}
addEventListener('hashchange',route);route();
