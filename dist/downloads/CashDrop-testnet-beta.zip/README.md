# CashDrop

CashDrop turns shielded ZEC into a one-time, encrypted bearer link. A sender creates a fresh Sapling address, funds it, and hands its portable spending authority to a recipient inside an authenticated-encrypted URL fragment. The recipient imports that key into their own local CashDrop bridge and sweeps the note without contacting the sender.

This repository contains a browser app and a loopback-only Node bridge for the official Zcash Z3 regtest stack (Zebra + Zallet). The browser never talks directly to wallet RPC and claim metadata is encrypted into the URL fragment, which browsers do not send to HTTP servers.

## Run locally

Requirements: Node 22+, Docker, and a running Zallet JSON-RPC endpoint. The server and key generator bind to `127.0.0.1` by default.

```powershell
docker compose -f docker-compose.keygen.yml up -d --build
$env:ZCASH_RPC_URL='http://127.0.0.1:50232'
$env:ZCASH_RPC_USER='zebra'
$env:ZCASH_RPC_PASSWORD='zebra'
$env:CASHDROP_NETWORK='regtest'
npm start
```

Open `http://127.0.0.1:4173`.

### Public testnet

With the official Z3 repository checked out beside this project and its testnet wallet initialized, run:

```powershell
.\scripts\start-testnet.ps1
```

This starts Zebra and Zallet, reads Zallet's rotating RPC cookie without printing it, and launches CashDrop with a testnet-only local data store. A fresh Zebra testnet sync is roughly 30 GB and commonly takes 2–12 hours. Do not accept deposits until the node is fully synchronized.

## Security boundaries

- The claim link is a bearer instrument containing spending authority. Anyone with it can attempt to claim first.
- The encrypted claim payload lives after `#` and is never included in web requests.
- Wallet RPC credentials and wallet state stay in the local bridge.
- Local drop records are isolated by network, preventing regtest and testnet accounts from being mixed.
- CashDrop binds to loopback and does not expose Zallet to the LAN.
- No analytics, account, cloud database, URL shortener, or link-preview service is used.
- The hosted marketing frontend never handles claims; claim links target the recipient's loopback app at `127.0.0.1`.
- Regtest is for development only. A mainnet release requires an external security review, installer signing, wallet backup/recovery hardening, and careful threat testing.

## Current protocol

1. Generate a standalone Sapling extended spending key and payment address in the localhost-only `librustzcash` key service.
2. Import that key into the sender's Zallet instance without rescanning old blocks.
3. Fund `amount + 0.0001 ZEC` to reserve the claim fee.
4. Detect the confirmed shielded balance.
5. Encrypt `{id, amount, note, network, source address, birthday height, spending key}` client-side with AES-256-GCM.
6. Place ciphertext and its encryption key in the URL fragment, which is not sent in HTTP requests.
7. On another device, import the spending key into that device's local Zallet and sweep with `z_sendmany` under `FullPrivacy`.

The original server-mediated flow was exercised end-to-end on regtest. In the portable-key v2 two-wallet acceptance run, a second Zallet imported the bearer key, rescanned from its birthday, and detected the exact funded `0.0101 ZEC` balance. Zallet beta.3 then rejected the standalone-account sweep in its synchronous PCZT path with `PCZTs require that ZIP 212 is enforced for outputs` under Z3's custom regtest activation schedule. Resolve or work around that upstream regtest path, then repeat the final sweep and public-testnet acceptance before submission.

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md), [docs/THREAT_MODEL.md](docs/THREAT_MODEL.md), and [docs/DEMO.md](docs/DEMO.md).

Run checks with `npm test` and `npm run check`.
