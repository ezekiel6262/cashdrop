use rand::{rngs::OsRng, RngCore};
use sapling_crypto::zip32::ExtendedSpendingKey;
use serde_json::json;
use std::{env, io::{Read, Write}, net::{TcpListener, TcpStream}};
use zcash_keys::encoding::{encode_extended_spending_key, encode_payment_address};
use zcash_protocol::constants::{mainnet, regtest, testnet};

fn keypair() -> serde_json::Value {
    let mut seed = [0u8; 32];
    OsRng.fill_bytes(&mut seed);
    let key = ExtendedSpendingKey::master(&seed);
    seed.fill(0);
    let (_, address) = key.default_address();
    let network = env::var("CASHDROP_NETWORK").unwrap_or_else(|_| "regtest".into());
    let (key_hrp, address_hrp) = match network.as_str() {
        "mainnet" => (mainnet::HRP_SAPLING_EXTENDED_SPENDING_KEY, mainnet::HRP_SAPLING_PAYMENT_ADDRESS),
        "regtest" => (regtest::HRP_SAPLING_EXTENDED_SPENDING_KEY, regtest::HRP_SAPLING_PAYMENT_ADDRESS),
        _ => (testnet::HRP_SAPLING_EXTENDED_SPENDING_KEY, testnet::HRP_SAPLING_PAYMENT_ADDRESS),
    };
    json!({
        "spendingKey": encode_extended_spending_key(key_hrp, &key),
        "sourceAddress": encode_payment_address(address_hrp, &address)
    })
}

fn respond(mut stream: TcpStream) {
    let mut request = [0u8; 2048];
    let read = stream.read(&mut request).unwrap_or(0);
    let line = String::from_utf8_lossy(&request[..read]);
    let (status, body) = if line.starts_with("GET /health ") {
        ("200 OK", json!({"ok": true}))
    } else if line.starts_with("POST /key ") {
        ("200 OK", keypair())
    } else {
        ("404 Not Found", json!({"error": "Not found"}))
    };
    let body = body.to_string();
    let response = format!(
        "HTTP/1.1 {status}\r\nContent-Type: application/json\r\nCache-Control: no-store\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}",
        body.len()
    );
    let _ = stream.write_all(response.as_bytes());
}

fn main() {
    let listener = TcpListener::bind("0.0.0.0:4174").expect("bind key service");
    for stream in listener.incoming().flatten() { respond(stream); }
}

